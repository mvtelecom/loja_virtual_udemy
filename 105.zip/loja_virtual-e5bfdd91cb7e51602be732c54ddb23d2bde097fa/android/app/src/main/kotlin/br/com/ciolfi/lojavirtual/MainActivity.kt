package br.com.ciolfi.lojavirtual

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
